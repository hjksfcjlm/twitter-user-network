import tweepy
import time
import csv
import sys
import json
import pandas as pd
import oauth2 as oauth

		# Keys, tokens and secrets
consumer_key = "xcluSovIpR3G8vqTdry1AEbF6"
consumer_secret = "kKkS6vSxxe5mRUpg68nI3vjO0jJcxVQPrn1ZQtp0MaU5qkiunj"
access_token = "936696151516045312-z4ZT9ks09FH2yE6dpUIWI6wlFGbBSZK"
access_token_secret = "bLxGW6L1BrJ80fXlxC7hAHeFbKn0K7OJqYXqMFjLWBsAb"

		# Tweepy OAuthHandler
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth)
consumer = oauth.Consumer(key=consumer_key, secret=consumer_secret)
access_token = oauth.Token(key=access_token, secret=access_token_secret)
client = oauth.Client(consumer, access_token)

	
#targets = ["Université Rennes 1"] # All your targets here
#Extract from api user object
user = api.get_user("UnivRennes1")
tweet = api.get_statuses("UnivRennes1")
print(tweet.retweet_count)


#extract from JSON stream tweet object fields
timeline_endpoint = "https://api.twitter.com/1.1/search/tweets.json?q=%23Rennes1&count=500" 
for friend in user.friends():
  print(user.id, user.followers_count, user.friends_count, user.statuses_count)
  response, data = client.request(timeline_endpoint)
  AllData=json.loads(data)
  print (tweet['entities']['user_mentions'],tweet['retweet_count']) 


	
	
		  
		