import tweepy
import time
import csv
import sys
import json
import pandas as pd
import oauth2 as oauth
import sqlite3 
"""
from tweepy import stream
from tweepy import OAuthHander
from tweepy.streaming import StreamListener 
"""

     #connect to sqlite database

conn = sqlite3.connect('users.db',timeout=5)
c = conn.cursor()

#creation table users
c.execute("CREATE TABLE IF NOT EXISTS Users ( user_id TEXT NOT NULL, username varchar(10), friend_count NUMERIC, follower_count NUMERIC, statuses_count NUMERIC, followers_list_id JSON, PRIMARY KEY(`user_id`))")
    

	# Keys, tokens and secrets
'''
consumer_key = "xcluSovIpR3G8vqTdry1AEbF6"
consumer_secret = "kKkS6vSxxe5mRUpg68nI3vjO0jJcxVQPrn1ZQtp0MaU5qkiunj"
access_token = "936696151516045312-z4ZT9ks09FH2yE6dpUIWI6wlFGbBSZK"
access_token_secret = "bLxGW6L1BrJ80fXlxC7hAHeFbKn0K7OJqYXqMFjLWBsAb"
'''
consumer_key = "SW8bvASrGDqTrLWBySS1DCN7j"
consumer_secret = "rYSjk9s0rXd8UMHit8cL7XYUzA6yWZBHGZ7VBt3lJUZU7G0Vns"
access_token =  "936696151516045312-aBJKgcPzSQnJPx6tqPxNBqpSnK5IoVq"
access_token_secret ="y40kS5kMfIpb1hMBOQs8OldYGKFH0Agii2B07IjRKCamU"


		# Tweepy OAuthHandler
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
#to wait rather than printing the time limit error       
api = tweepy.API(auth,wait_on_rate_limit=True)
consumer = oauth.Consumer(key=consumer_key, secret=consumer_secret)
access_token = oauth.Token(key=access_token, secret=access_token_secret)
client = oauth.Client(consumer, access_token)

"""
class listener (StreamListener):
       def on_data (self,data):
	       print data
		   return True
	   def on_error (self,status):
	       print status
	

# Initiate the connection to Twitter Streaming API
#twitter_stream = TwitterStream(auth=oauth)
twitterStream = Stream(auth, Listener())
twitterStream.filter()
"""

#extracting users
user = api.get_user("UnivRennes1")
'''
followers_list0=[]
for cursor in tweepy.Cursor(api.followers,screen_name=user.screen_name).items():
   try:
	   followers_list0.append(cursor.id_str)
   except tweepy.TweepError:
       time.sleep(60 * 15)
       continue
   except StopIteration:
       break
# Insert into db
c.execute('insert or ignore into Users values(?,?,?,?,?,?)',(user.id_str,"UnivRennes1",user.friends_count,user.followers_count,user.statuses_count,json.dumps(followers_list0)))
'''
for friend in user.friends():
  user1 = api.get_user(friend.screen_name)
  followers_list=[]
  for cursor in tweepy.Cursor(api.followers,screen_name=user1.screen_name).items():
       followers_list.append(cursor.id_str)
  c.execute('insert or ignore into Users values(?,?,?,?,?,?)',(user1.id_str,user1.screen_name,user1.friends_count,user1.followers_count,user1.statuses_count,json.dumps(followers_list)))
  print(user1.screen_name,user1.id_str,user1.followers_count,user1.friends_count,user1.statuses_count,followers_list)
  '''
  for f1 in user1.friends():
	  #Extracting the list of followers from the specific user
	  #the list of ids of the followers of every user
     followers_list1=[]
     for cursor in tweepy.Cursor(api.followers,screen_name=f1.screen_name).items():
	  		  followers_list1.append(cursor.id_str)
	 	      #inserting all data in the data base
     c.execute('insert or ignore into Users values(?,?,?,?,?,?)',(f1.id_str,f1.screen_name,f1.friends_count,f1.followers_count,f1.statuses_count,json.dumps(followers_list1)))
     print(f1.screen_name,f1.id_str,f1.followers_count,f1.friends_count,f1.statuses_count,followers_list1)
  print(f1.screen_name,f1.id_str,f1.followers_count,f1.friends_count,f1.statuses_count)
  '''
conn.commit()
c.close()
 