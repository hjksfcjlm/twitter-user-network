import tweepy
import time
import csv
import sys
import json
import pandas as pd
import oauth2 as oauth
import sqlite3 
"""
from tweepy import stream
from tweepy import OAuthHander
from tweepy.streaming import StreamListener 
"""

     #connect to sqlite database

conn = sqlite3.connect('users.db',timeout=5)
c = conn.cursor()

#creation table users
#c.execute("CREATE TABLE IF NOT EXISTS Users ( user_id TEXT NOT NULL, username varchar(10), friend_count NUMERIC, follower_count NUMERIC, statuses_count NUMERIC, followers_list_id JSON, PRIMARY KEY(`user_id`))")
    

	# Keys, tokens and secrets

consumer_key = "xcluSovIpR3G8vqTdry1AEbF6"
consumer_secret = "kKkS6vSxxe5mRUpg68nI3vjO0jJcxVQPrn1ZQtp0MaU5qkiunj"
access_token = "936696151516045312-z4ZT9ks09FH2yE6dpUIWI6wlFGbBSZK"
access_token_secret = "bLxGW6L1BrJ80fXlxC7hAHeFbKn0K7OJqYXqMFjLWBsAb"


		# Tweepy OAuthHandler
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
#to wait rather than printing the time limit error       
api = tweepy.API(auth,wait_on_rate_limit=True)
consumer = oauth.Consumer(key=consumer_key, secret=consumer_secret)
access_token = oauth.Token(key=access_token, secret=access_token_secret)
client = oauth.Client(consumer, access_token)

#extracting users
user = api.get_user("UnivRennes1")


#for status in api.user_timeline(screen_name='acmigdtuw',include_rts=1,count=200):
#    print status.id'''

'''
#verify the table line by line
followers_list[]
for row in c.execute('select username from Users1 where followers_list_id =" " '):
		      for cursor in tweepy.Cursor(api.followers,screen_name=username).items():
		           followers_list.append(cursor.id_str)
			  print(followers_list)
		      c.execute('insert or ignore into Users values(,,,,,?)',(json.dumps(followers_list)))			 
'''
followers_list=[]
for cursor in tweepy.Cursor(api.followers,screen_name="UnivRennes1").items():
		           followers_list.append(cursor.id_str)
print(followers_list)

conn.commit()
c.close()
 			 